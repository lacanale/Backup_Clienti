NOTE: Option features are only available in the EXPERT version of the DaS program and not in the LIGHT version.

This is the help file for the DaS program version 4.03 from ASCO/JOUCOMATIC.
This software only works with the SentronicD valve controller firmware version 7 or greater.

MINIMUM SYSTEM REQUIREMENTS:
Pentium II, 800 MHz, 32 Mbyte RAM, Windows 9x/Windows 2000/Windows NT 4.0
1.	INSTALLATION PROCEDURE
 
From the Windows� Start menu, click Run...  In the Open field type:
- Instal-E" to install the English version.
- Instal-G" to install the German version.
- Instal-F" to install the French version.

Follow the instructions on the screen.

A "C:\Sentronic-Xp-V403" or "C:\Sentronic-V403" directory is created on your hard-drive C:\ and all needed files are copied to this directory. The program will be 
installed in the language you have selected.

If a "C:\Sentronic-Xp-V402" or "C:\Sentronic-V403" directory already exists, an error message is returned. The installation procedure will, however, still work 
correctly. The directory will not be completely overwritten, your project files will be preserved. Only the program and language files 
are updated.

1.1	GETTING STARTED
Double-click the DaS.exe file now located on your hard drive.
Alternatively, drag and drop the "DaS-Xp4.02"  or "DaS-Lt4.03" icon from the "C:\Sentronic-Xp-V403" or "C:\Sentronic-V403" directory to your desktop and double-click this 
icon.
